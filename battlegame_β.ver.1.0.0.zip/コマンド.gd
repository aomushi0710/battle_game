extends VBoxContainer

var button = preload("res://バトル技セレクト.tscn")
var actions_data = Global.actions_data
var result = 0
var act_range = [] # 乱数幅格納
var actions = [] # 現在コマンド選択可能な技のidを格納
var action = 0 # 選択した技のid
var act_ids = []
var children = []
var i = 3 # Global.targetから、あるいはランダムに選ばれたindexを登録する
var i_1 = 0 # 繰り返し変数
var i_2 = 0 # index
var i_3 = 0 # 繰り返し変数

signal mp_update
signal spd
signal command

func _on_p_1_spd_command(): # 一旦、actionsにappendし、後でまとめてボタンインスタンスを
	for i_1 in (4 - len(actions)): # 生成することでindexの位置のズレをなくす。
		result = randi() % 100 # 0~99の100通りの乱数を生成
		if result <= act_range[0]: # 乱数に応じて出現する技を決定
			actions.append(Global.deck1[0]["actions"].keys()[0])
		elif result <= act_range[1]:
			actions.append(Global.deck1[0]["actions"].keys()[1])
		elif result <= act_range[2]:
			actions.append(Global.deck1[0]["actions"].keys()[2])
		elif result <= act_range[3]:
			actions.append(Global.deck1[0]["actions"].keys()[3])
	for button in $".".get_children():
			button.queue_free()
	for i_2 in range(len(actions)):
		var act = button.instantiate()
		act.text = actions_data[actions[i_2]]["name"]
		act.icon = load(actions_data[actions[i_2]]["type"])
		act.button_up.connect(func():select_command(i_2))
		add_child(act)
	i_2 = 0

func _on_player_1_randomize_set(): # 乱数幅設定
	randomize()
	var sum_range = 0
	for key in Global.deck1[0]["actions"]:
		var range = Global.deck1[0]["actions"][key]
		if i_3 == 0:
			range -= 1
			i_3 = 1
		sum_range += range # ex.1:10% 2:20% 3:30% 4:40%なら、[9,29,59.99]となり、
		act_range.append(sum_range) # 乱数0~9の範囲で1が、10~29で2、30~59で3、60~99で4
	i_3 = 0

func select_command(x): # x 押されたボタンの技のindex
	for act in $".".get_children():
		act.disabled = true # 全てのボタンを使用不可に
		children.append(act) # 配列に登録
	remove_child(children[x]) # 押されたボタンだけ消す
	children.clear() # 初期化処理
	action = actions.pop_at(x) # actionsから、選ばれたactionのidだけを削除して挿入
	print(actions)
	command.emit(action,0) # action:技id 0:味方モンスターの位置
	spd.emit()

func _on_buttle_evolution_1(): # モンスターが進化した場合、すでに手持ちにある技が進化技に置き換わる
	for index in range(3):
		if actions[index] == "10002":
			actions[index] = Global.deck1[0]["evolution"]

func _on_buttle_evolution_middle_1():
	for index in range(3):
		if actions[index] == "10001":
			actions[index] = Global.deck1[0]["evolution_middle"]
