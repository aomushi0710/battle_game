extends TextureProgressBar

var spd = 0
var spd_percent = 0
var spd_percent_text = ""

signal mp
signal command

func _on_tree_entered(): # enemiesの相手デッキ生成スクリプトが作動してからステータスを取得しなければならない
	spd = int(Global.monsters_data[Global.enemy_deck[0]["id"]]["default"]["status"]["SPD"])

func _process(delta): # ゲージが溜まるまで自動で増加、溜まると停止
	if $".".value < 500: # SPDの値ずつ毎秒増加していき、500まで到達するとコマンドリストを表示
		$".".value += spd * delta
		spd_percent = int($".".value / 5)
		call("text_update")
	elif $".".value == 500:
		set_process(false)
		#$"/root/Node2D/log_window/log".text += (
				#"相手の" + Global.monsters_data[Global.enemy_deck[0]["id"]]["default"]["name"] + 
				#"が行動可能になった！\n")
		command.emit()
		mp.emit()

func text_update():
	if spd_percent < 10:
		spd_percent_text = "  " + str(spd_percent)
	elif spd_percent < 100:
		spd_percent_text = " " + str(spd_percent)
	else:
		spd_percent_text = str(spd_percent)
	$spd_text.text = "[color=green][b]SPD[/b]   " + spd_percent_text + "%[/color]" 

func _on_コマンド_spd():
	$".".value = 0
	set_process(true)

func _on_enemies_evolution_1():
	spd = int(Global.monsters_data[Global.enemy_deck[0]["id"]]["evolution"]["status"]["SPD"])

func _on_enemies_evolution_middle_1():
	spd = int(Global.monsters_data[Global.enemy_deck[0]["id"]]["evolution_middle"]["status"]["SPD"])
