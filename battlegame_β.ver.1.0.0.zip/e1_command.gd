extends VBoxContainer

var button = preload("res://バトル技セレクト.tscn")
var monsters_data = Global.monsters_data
var actions_data = Global.actions_data
var result = 0
var act_range = [] # 乱数幅格納
var actions = [] # 現在コマンド選択可能な技のidを格納
var action = 0 # 選択した技のid
var children = []
var ai_act = 0 # npcの挙動制御用、候補となった技のidを格納
var ai_actions = [] # npcの挙動制御用、候補となった技のidを格納
var ai_action = 0 # npcの挙動制御用、決定された技のidを格納
var ai_mp = 999 # npcの挙動制御用、mp要求量の比較
var i = 3 # Global.targetから、あるいはランダムに選ばれたindexを登録する
var i_1 = 0 # 繰り返し変数
var i_2 = 0 # index
var i_3 = 0 # 繰り返し変数
var i_4 = 0 # 繰り返し変数

signal mp_update
signal spd
signal command

func _on_p_1_spd_command(): # 一旦、actionsにappendし、後でまとめてボタンインスタンスを
	for i_1 in (4 - len(actions)): # 生成することでindexの位置のズレをなくす。
		result = randi() % 100 # 0~99の100通りの乱数を生成
		print("乱数",result)
		if result <= act_range[0]: # 乱数に応じて出現する技を決定
			actions.append(Global.enemy_deck[0]["actions"].keys()[0])
		elif result <= act_range[1]:
			actions.append(Global.enemy_deck[0]["actions"].keys()[1])
		elif result <= act_range[2]:
			actions.append(Global.enemy_deck[0]["actions"].keys()[2])
		elif result <= act_range[3]:
			actions.append(Global.enemy_deck[0]["actions"].keys()[3])
	for button in $".".get_children():
			button.queue_free()
	for i_2 in range(len(actions)):
		var act = button.instantiate()
		act.disabled = true
		act.text = Global.actions_data[actions[i_2]]["name"]
		act.icon = load(Global.actions_data[actions[i_2]]["type"])
		add_child(act)
	i_2 = 0
	
	# 以下、技選択npcプロセス
	if "10001" in Global.enemy_deck[0]["actions"] or "10002" in Global.enemy_deck[0]["actions"]:
		# まだ進化していないモンスターの挙動
		if (
				"10001" in actions and int($"../e1_mp".value) >= 
				int(monsters_data[Global.enemy_deck[0]["id"]]["evolution_middle"]["cost"])):
			ai_action = "10001" # mpが足りていたら進化する
		elif (
				"10002" in actions and int($"../e1_mp".value) >= 
				int(monsters_data[Global.enemy_deck[0]["id"]]["evolution"]["cost"])):
			ai_action = "10002"
		else:
			for act_id in actions: # 全ての候補の技の要求mpを比較する
				if ai_mp > int(actions_data[act_id]["mp"]): # mp要求量が下回った時
					ai_actions.clear() # 配列を初期化して要求mp量がより少ないものに刷新する
					ai_mp = int(actions_data[act_id]["mp"])
					ai_actions.append(act_id)
				elif ai_mp == int(actions_data[act_id]["mp"]): # mp要求量が同じだった時
					ai_actions.append(act_id) # 要求mp量が同じ技を配列にまとめる
			ai_action = ai_actions[randi() % len(ai_actions)]
		for i_3 in actions: # 選ばれた技の位置のindexを引数として関数を呼ぶ
			if ai_action == i_3:
				call("select_command",i_4)
				i_4 = 0
				break
			i_4 += 1
	else: # 進化技を持たないモンスターの挙動
		ai_action = actions[randi() % len(actions)]
		for i_3 in actions: # 選ばれた技の位置のindexを引数として関数を呼ぶ
			if ai_action == i_3:
				call("select_command",i_4)
				i_4 = 0
				break
			i_4 += 1

func _on_player_1_randomize_set(): # 乱数幅設定
	randomize()
	var sum_range = 0
	for key in Global.enemy_deck[0]["actions"]:
		var range = Global.enemy_deck[0]["actions"][key] - 1
		sum_range += range # ex.1:10% 2:20% 3:30% 4:40%なら、[9,29,59.99]となり、
		act_range.append(sum_range) # 乱数0~9の範囲で1が、10~29で2、30~59で3、60~99で4

func select_command(x): # x 押されたボタンの技のindex
	for button in $".".get_children():
		children.append(button) # 配列に登録
	remove_child(children[x]) # 押されたボタンだけ消す
	children.clear() # 初期化処理
	action = actions.pop_at(x) # actionsから、選ばれたactionのidだけを削除して挿入
	command.emit(action,0) # action:技id 0:味方モンスターの位置
	spd.emit()

func _on_enemies_evolution_1(): # モンスターが進化した場合、すでに手持ちにある技が進化技に置き換わる
	for index in range(3):
		if actions[index] == "10002":
			actions[index] = Global.enemy_deck[0]["evolution"]

func _on_enemies_evolution_middle_1():
	for index in range(3):
		if actions[index] == "10001":
			actions[index] = Global.enemy_deck[0]["evolution_middle"]
