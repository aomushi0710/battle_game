extends Control

var first_texture = load("res://1st.PNG")
var second_texture = load("res://2nd.PNG")
var third_texture = load("res://3rd.PNG")
var act_name = ""
var detail = ""
@onready var deck_monster1 = $first
@onready var deck_monster2 = $second
@onready var deck_monster3 = $third
@onready var test = get_node("デッキ1")

# 押したボタンの場所のモンスターを選択
func _on_first_button_up():
	get_tree().change_scene_to_packed(Global.chara_scene)
	Global.now_picking = 0

func _on_second_button_up():
	get_tree().change_scene_to_packed(Global.chara_scene)
	Global.now_picking = 1

func _on_third_button_up():
	get_tree().change_scene_to_packed(Global.chara_scene)
	Global.now_picking = 2


func _on_デッキセレクト_tree_entered():
	print(Global.deck1)
	for i in range(3):
		if Global.deck1[i]["id"] == 0:
			pass
		else:
			if i == 0:
				$first.texture_normal = load(Global.monsters_data[Global.deck1[i]["id"]]["default"]["img"])
			if i == 1:
				$second.texture_normal = load(Global.monsters_data[Global.deck1[i]["id"]]["default"]["img"])
			if i == 2:
				$third.texture_normal = load(Global.monsters_data[Global.deck1[i]["id"]]["default"]["img"])
	if Global.deck1[0]["id"] != 0:
		for key in Global.deck1[0]["actions"]:
			detail += (
					"[img=20]" + Global.actions_data[key]["type"] + 
					"[/img]" + Global.actions_data[key]["name"] + "\n")
		$first/詳細.text = detail
		detail = ""
	Global.now_picking = 3


func _on_first_focus_entered():
	$first/詳細.show()


func _on_test_button_up():
	if Global.deck1[0]["id"] != 0 and Global.deck1[1]["id"] != 0 and Global.deck1[2]["id"] != 0:
		get_tree().change_scene_to_packed(Global.buttle_scene)
	else:
		$エラーメッセージ.show()
