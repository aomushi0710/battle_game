extends ProgressBar

