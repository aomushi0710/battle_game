extends TextureProgressBar

