extends Button

func _on_toggled(toggled_on):
	if toggled_on == true:
		$ColorRect.show()
		$help_label.show()
		get_tree().paused = true
	else:
		$ColorRect.hide()
		$help_label.hide()
		get_tree().paused = false
