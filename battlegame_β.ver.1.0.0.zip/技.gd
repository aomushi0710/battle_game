extends VBoxContainer

@onready var tab = get_node("セレクトUI/技")
var button = preload("res://技セレクトボタン.tscn")
var actions_data = Global.actions_data
var monster_data = Global.monsters_data
var monster_id = Global.selected_monster
var actions = []
var now_select_action = 0

signal select

func _on_tree_entered():
	for i in monster_data[monster_id]["default"]["action"]:
		actions.append(i) # jsonから読み込んだ技のname,type,idを格納
	for i in range(len(actions)):
		call("_on_set_button",i)

func _on_set_button(x):
	var act = button.instantiate()
	act.text = actions[x]["name"]
	act.icon = load(actions[x]["type"])
	act.button_up.connect(func():_on_button_toggled(x))
	add_child(act)

func _on_button_toggled(x):
	now_select_action = actions[x]["id"]
	select.emit(now_select_action)
	
