extends Control

var selected_skill = 0 # 選ばれたスキルパターン
var now_select_action = 0 # 現在指定されている技
var pattern = [] # jsonから読み込んだパターンを格納
var middle_evol_action = {} # jsonから読み込んだ中間進化技を格納
var evol_action = {} # jsonから読み込んだ進化技を格納
var sum_chance = 0 # 出現率の合計
var monsters_data = Global.monsters_data # モンスターの各種データ取得
var monster_id = Global.selected_monster
var actions = [] 
var actions_data = Global.actions_data # jsonから読み込んだ技を格納
var selected_action = {} # 選ばれた技とその出現率(id:出現率)
var value = 0 # ui_update内変数
var i = 0 # forループ処理用index
var slider_i = 0 # forループ処理用index(slider)
var text_i = 0 # forループ処理用index(text)
var check_provability = [] # 出現率0%弾き出し用

func _ready():
	pass

func _on_戻る_button_up():
	call("reset")
	get_tree().change_scene_to_packed(Global.chara_scene)

func _on_決定_button_up():
	if sum_chance != 100:
		$エラーメッセージ.dialog_text = "出現率の合計が100%ではありません！"
		$エラーメッセージ.show()
	elif float(0) in selected_action.values():
		$エラーメッセージ.dialog_text = "出現率が0%の技は選択を解除してください！"
		$エラーメッセージ.show()
	elif (
			middle_evol_action["id"] != "" and evol_action["id"] in selected_action.keys() and 
			middle_evol_action["id"] not in selected_action.keys()):
		$エラーメッセージ.dialog_text = "中間進化技が選択されていません！\nこのモンスターは進化が2回必要です"
		$エラーメッセージ.show()
	elif selected_skill == 0:
		$エラーメッセージ.dialog_text = "スキルが選択されていません！"
		$エラーメッセージ.show()
	else:
		Global.deck1[Global.now_picking]["id"] = monster_id
		Global.deck1[Global.now_picking]["skill"] = selected_skill
		Global.deck1[Global.now_picking]["actions"] = selected_action.duplicate(true)
		Global.deck1[Global.now_picking]["form"] = "default"
		if evol_action["id"] in selected_action.keys():
			Global.deck1[Global.now_picking]["evolution"] = evol_action["id"]
		if middle_evol_action["id"] in selected_action.keys():
			Global.deck1[Global.now_picking]["evolution_middle"] = middle_evol_action["id"]
		print(Global.deck1)
		call("reset")
		get_tree().change_scene_to_packed(Global.deck_scene)

func _on_node_2d_tree_entered(): # monsters.jsonからモンスターの持つ技のデータを抽出して代入
	for i in monsters_data[monster_id]["pattern"]:
		pattern.append(i) # 以下3行:jsonから読み込んだスキルパターンを格納
	$セレクトUI/スキル/スキルボタン.set_item_text(0,pattern[0])
	$セレクトUI/スキル/スキルボタン.set_item_text(1,pattern[1])
	for i in monsters_data[monster_id]["default"]["action"]:
		actions.append(i) # jsonから読み込んだ技のname,type,idを格納
	evol_action = monsters_data[monster_id]["evolution"]["action"] # 進化技情報取得
	middle_evol_action = monsters_data[monster_id]["evolution_middle"]["action"] # 進化技情報取得
	if evol_action["id"] != "":
		$セレクトUI/進化技/evolution.text = evol_action["name"]
		$セレクトUI/進化技/evolution.icon = load(evol_action["type"])
		$セレクトUI/進化技/evolution.show()
	if middle_evol_action["id"] != "":
		$セレクトUI/中間進化技/evolution_middle.text = middle_evol_action["name"]
		$セレクトUI/中間進化技/evolution_middle.icon = load(middle_evol_action["type"])
		$セレクトUI/中間進化技/evolution_middle.show()
	call("_on_技_mouse_entered")
	selected_action.clear() # 以下2行、初期化処理
	sum_chance = 0

func _on_スキルボタン_item_selected(index): # オプションボタンで選んだパターンを登録
	selected_skill = index + 1

func _on_evolution_middle_toggled(toggled_on):
	now_select_action = middle_evol_action["id"]
	call("_on_技_select",now_select_action)
	
func _on_evolution_toggled(toggled_on): # 進化技登録
	now_select_action = evol_action["id"]
	call("_on_技_select",now_select_action)

func _on_技_select(x):
	if str(x) in selected_action: # すでに登録されている技をもう一度選択して解除
		print("技選択解除")
		selected_action.erase(str(x))
		Global.selected_action_name = selected_action.keys()
		call("ui_update")
		now_select_action = 0
	elif sum_chance >= 100:
		print("出現率超過")
		$エラーメッセージ.dialog_text = "出現率の合計が100%を越えています！"
		$エラーメッセージ.show()
	else:
		selected_action[x] = 1 # 出現率1%で仮登録、スライダーで確率は調整できる
		Global.selected_action_name.append(x) # 技ID登録
		call("ui_update")
	
func ui_update(): # 先にsliderのvalueを取得しなければlabelのtextを更新できないためforループを2つ使用せざるを得ない
	sum_chance = 0 # 初期化処理
	for act_ui in $出現率設定UI.get_children(): # 子ノードをforループ
		if act_ui is HSlider: # act_uiがHSlider型の時、value取得
			if len(Global.selected_action_name) > slider_i:
				act_ui.max_value = float(actions_data[(Global.selected_action_name[slider_i])]["max_frequency"])
				selected_action[str(Global.selected_action_name[slider_i])] = int(act_ui.get_value())
				act_ui.editable = true
			else: # selected_actionが空の場合、sliderのvalueを0に初期化し、無効化する
				act_ui.set_value_no_signal(0) # この関数を使うとvalue_changedに影響を与えずにvalueを変更できる
				act_ui.editable = false
			slider_i += 1
		i += 1
	i = 0
	for act_ui in $出現率設定UI.get_children():
		if act_ui is RichTextLabel: # act_uiがRichTextLabel型の時、textの表示を変更する
			if len(Global.selected_action_name) > text_i:
				act_ui.text = (
						"[img=40]" + actions_data[Global.selected_action_name[text_i]]["type"] + 
						"[/img]" + actions_data[Global.selected_action_name[text_i]]["name"] + 
						" : [color=red]" + str(selected_action[str(Global.selected_action_name[text_i])]) + "%[/color]")
			else: # selected_actionが空の場合、textを未設定とする
				act_ui.text = "未設定"
			text_i += 1
		i += 1
	for i in selected_action.values(): # 出現率の合計値を取得
		sum_chance += i
	i = 0 # 以下5行、初期化処理
	now_select_action = 0
	slider_i = 0
	text_i = 0

func _on_act_slider_1_value_changed(value):
	selected_action[Global.selected_action_name[0]] = value
	call("ui_update")

func _on_act_slider_2_value_changed(value):
	selected_action[Global.selected_action_name[1]] = value
	call("ui_update")

func _on_act_slider_3_value_changed(value):
	selected_action[Global.selected_action_name[2]] = value
	call("ui_update")

func _on_act_slider_4_value_changed(value):
	selected_action[Global.selected_action_name[3]] = value
	call("ui_update")

func _on_進化技_mouse_entered():
	if evol_action["id"] != "":
		$monster.texture = load(monsters_data[monster_id]["evolution"]["img"])
		call("status_text",monster_id,"evolution")

func _on_中間進化技_mouse_entered():
	if middle_evol_action["id"] != "":
		$monster.texture = load(monsters_data[monster_id]["evolution_middle"]["img"])
		call("status_text",monster_id,"evolution_middle")

func _on_技_mouse_entered():
	$monster.texture = load(monsters_data[monster_id]["default"]["img"])
	call("status_text",monster_id,"default")

func status_text(i,form):
	if form == "default":
		$monster/title.text = "\n"
	elif form == "evolution_middle":
		$monster/title.text = "[color=yellow]中間進化語のステータス[/color]\n"
	elif form == "evolution":
		$monster/title.text = "[color=red]進化後のステータス[/color]\n"
	$monster/status.text = (
			"[b][i]「" + monsters_data[i][form]["name"] + "」[/i][/b]\n[img=50]" + 
			monsters_data[i][form]["main_type"] + "[/img][img=50]" + monsters_data[i][form]["sub_type"] + 
			"[/img] " + Global.type_changer_text[monsters_data[i][form]["main_type"]] + 
			" " + Global.type_changer_text[monsters_data[i][form]["sub_type"]] + "\n[color=red]HP:" +
			str(monsters_data[i][form]["status"]["HP"]) + "[/color] [color=green]SPD:" + 
			str(monsters_data[i][form]["status"]["SPD"]) + "[/color]\n[color=aqua]MP(supply/max)\n:" + 
			str(monsters_data[i][form]["status"]["supplyMP"]) + "/" + 
			str(monsters_data[i][form]["status"]["maxMP"]) + "[/color]\n[color=red]ATK:" + 
			str(monsters_data[i][form]["status"]["ATK"]) + "[/color] [color=light_blue]DEF:" + 
			str(monsters_data[i][form]["status"]["DEF"]) + "[/color]\n[color=blue]MAG:" + 
			str(monsters_data[i][form]["status"]["MAG"]) + "[/color] [color=purple]RES:" + 
			str(monsters_data[i][form]["status"]["RES"]) + "[/color]")

func reset():
	for act_ui in $出現率設定UI.get_children():
		if act_ui is HSlider:
			act_ui.set_value_no_signal(0)
			act_ui.editable = false
	Global.selected_action_name.clear()
	selected_skill = 0
	selected_action.clear()
	middle_evol_action = ""
	evol_action = ""
