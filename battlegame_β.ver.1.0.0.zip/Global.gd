extends Node2D

@onready var monsters_file = FileAccess.open("res://monsters.json", FileAccess.READ)
@onready var monsters_data = JSON.parse_string(monsters_file.get_as_text())
@onready var actions_file = FileAccess.open("res://actions.json", FileAccess.READ)
@onready var actions_data = JSON.parse_string(actions_file.get_as_text())

var deck_scene = load("res://デッキセレクト.tscn")
var chara_scene = load("res://キャラ選択.tscn")
var select_scene = load("res://特性・技セレクト.tscn")
var buttle_scene = load("res://バトル.tscn")

@onready var picked_monster = [0,0,0] #１枠目のモンスター
@onready var deck1 = [{"id":0},{"id":0},{"id":0}]
@onready var enemy_deck = [{"id":0,"actions":{}},{"id":0,"actions":{}},{"id":0,"actions":{}}]
@onready var target = 3 # 現在攻撃対象に選択中のモンスターの位置(0~2:指定indexのモンスターを攻撃 3:未選択)
@onready var selected_action_name = [] # 選ばれた技名(id)

@onready var now_picking = 3 #現在選択中のモンスターの位置　3：未選択 0～2：選択中
@onready var selected_monster = 0 #現在選択中のモンスターID(特性・技セレクトで使用)

# jsonに記入するほどの情報ではないが、テキスト化して表示するがある、また規則性を持っていたため
# 全てを辞書に挿入し、実質的にjsonの情報に追記することとした。
@onready var type_changer_text = {
		"res://無属性.PNG":"無属性","res://火属性.PNG":"[color=red]火属性[/color]",
		"res://水属性.PNG":"[color=blue]水属性[/color]",
		"res://雷属性.PNG":"[color=yellow]雷属性[/color]",
		"res://土属性.PNG":"[color=brown]土属性[/color]",
		"res://風属性.PNG":"[clor=green風属性[/color]",
		"res://氷属性.PNG":"[color=aqua]氷属性[/color]",
		"res://光属性.PNG":"[color=light_yellow]光属性[/color]",
		"res://闇属性.PNG":"[color=purple]闇属性[/color]","":""}
@onready var type_changer_id = {
		"res://無属性.PNG":0,"res://火属性.PNG":1,"res://水属性.PNG":2,
		"res://雷属性.PNG":3,"res://土属性.PNG":4,"res://風属性.PNG":5,
		"res://氷属性.PNG":6,"res://光属性.PNG":7,"res://闇属性.PNG":8,"":-1}
