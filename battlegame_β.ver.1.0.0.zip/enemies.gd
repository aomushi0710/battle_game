extends Control

var monsters_data = Global.monsters_data
var actions_data = Global.actions_data
var action_id = 0
var sum_chance = 0
var action_ids = []
var provability = 0
var n = 0
var zero_check = 0
var while_i = 0 # 繰り返し変数
var evolution_id = ""
var value = 0

var target = 0
var mp_cost = 0 # 消費mpが変動する技の必要mp取得用
var ma = 1.0 # タイプ相性ダメージ倍率 関数内処理用
var ma2 = 1.0 # (magnificationの略) ダメージ計算処理用
var dmg_type = [] # 物理技ならatk,def 魔法技ならmag,resが入る
var o_sub = -1 # 攻撃側が複合属性攻撃を行う際に使用、そうでないなら-1が入る
var monster_id = 0
var monster_form = ""
var enemy_id = 0
var enemy_form = ""
var damage = 0 # 計算済みのダメージを挿入する

signal damage1
signal damage2
signal damage3
signal evolution1
signal evolution2
signal evolution3
signal evolution_middle1
signal evolution_middle2
signal evolution_middle3
signal mp

func _on_tree_entered(): # 選択可能なモンスター、技からランダムにチームを編成します。
	for i_1 in range(3): # 全モンスターからランダムに選ぶ。i_1は0-2が入りモンスターの位置を表す。
		while zero_check == 0: # zero_checkに0が入った場合再度抽選を行い、0以外の数字のみを選ぶ。
		# Global.enemy_deck[i_1]["id"] は敵モンスター[i_1]枠目のモンスターidが入ります
			zero_check = randi() % (len(monsters_data))
		Global.enemy_deck[i_1]["id"] = zero_check # 0以外が入った場合、ループをはずれ、挿入
		zero_check = 0 # 初期化
		Global.enemy_deck[i_1]["skill"] = randi() % 2 # スキルパターンindexを0or1に設定
		# まず全ての選択可能な技のidを取り出し、action_idsに登録する。
		for i_2 in monsters_data[Global.enemy_deck[i_1]["id"]]["default"]["action"]:
			action_ids.append(i_2["id"])
		# もし進化技があれば進化技も対象に加える、中間進化技についても同様
		if monsters_data[Global.enemy_deck[i_1]["id"]]["evolution"]["action"]["id"] != "":
			action_ids.append(monsters_data[Global.enemy_deck[i_1]["id"]]["evolution"]["action"]["id"])
		if monsters_data[Global.enemy_deck[i_1]["id"]]["evolution_middle"]["action"]["id"] != "":
			action_ids.append(
					monsters_data[Global.enemy_deck[i_1]["id"]]["evolution_middle"]["action"]["id"])
		while sum_chance < 100: # 合計出現率が100%になるまでモンスターの持つ全技からランダムに選ぶ。
			# n には全ての選択可能な技のindexが入ります
			n = randi() % len(action_ids)
			# action_id にはnに入ったindexの位置の技idが入ります
			action_id = action_ids.pop_at(n)
			if while_i == 3: # 4つ目の技を設定する時は、ちょうど100%になるように調整される。
				provability = 100 - sum_chance
				Global.enemy_deck[i_1]["actions"][action_id] = provability
			else:
				# provability にはaction_idに入った技の出現率が入ります。
				# もし残りの%よりも最大設定可能出現率が小さければ、そちらを優先し、100%以上にならないようにする。
				if 100 - sum_chance > int(actions_data[action_id]["max_frequency"]):
					provability = randi() % (int(actions_data[action_id]["max_frequency"]) + 1)
				else:
					provability = randi() % (100 - sum_chance) + 1
				Global.enemy_deck[i_1]["actions"][action_id] = provability
			sum_chance += provability
			while_i += 1
		if ( # もし、進化技が選ばれた場合、evolutionキーに登録する。
				monsters_data[Global.enemy_deck[i_1]["id"]]["evolution"]["action"]["id"]
				in Global.enemy_deck[i_1]["actions"].keys()):
			Global.enemy_deck[i_1]["evolution"] = (
					monsters_data[Global.enemy_deck[i_1]["id"]]["evolution"]["action"]["id"])
		if (
				monsters_data[Global.enemy_deck[i_1]["id"]]["evolution_middle"]["action"]["id"]
				in Global.enemy_deck[i_1]["actions"].keys()):
			Global.enemy_deck[i_1]["evolution_middle"] = (
					monsters_data[Global.enemy_deck[i_1]["id"]]["evolution_middle"]["action"]["id"])
		Global.enemy_deck[i_1]["form"] = "default"
		sum_chance = 0 # ループを抜けたので初期化
		while_i = 0
		action_ids.clear()
	print(Global.enemy_deck)

func attribute_setup(off_type_main,off_type_sub,def_type_main,def_type_sub):
	ma = 1.0 # 初期化処理   off_type:攻撃側タイプ def_type:防御側タイプ
	if off_type_sub == -1 and def_type_sub == -1: # -1:該当なし
		ma *= attribute(off_type_main,def_type_main)
	elif off_type_sub != -1 and def_type_sub == -1: # 攻撃側が複合タイプ攻撃
		ma *= attribute(off_type_main,def_type_main)
		ma *= attribute(off_type_sub,def_type_main)
	elif off_type_sub == -1 and def_type_sub != -1: # 防御側が複合タイプ持ち
		ma *= attribute(off_type_main,def_type_main)
		ma *= attribute(off_type_main,def_type_sub)
	elif off_type_sub != -1 and def_type_sub != -1: # どちらも複合タイプ持ち
		ma *= attribute(off_type_main,def_type_main)
		ma *= attribute(off_type_sub,def_type_main)
		ma *= attribute(off_type_main,def_type_sub)
		ma *= attribute(off_type_sub,def_type_sub)
	return ma
	
func attribute(o,d):
	if ( # 0:無 1:火 2:水 3:雷 4:土 5:風 6:氷 7:光 8:闇
			(o == 2 and d == 1) or (o == 3 and d == 2) or (o == 4 and d == 3) or 
			(o == 5 and d == 4) or (o == 6 and d == 5) or (o == 1 and d == 6) or 
			(o == 7 and d == 8) or (o == 8 and d == 7)):
		return 2.0 # 弱点を突いたときダメージ2倍
	elif o == d and o != 0:
		return 0.5 # 同じ属性の技を受けた時ダメージ0.5倍
	elif o == 0 and d != 0:
		return 0.8 # 無属性でない敵に無属性の技で攻撃する際の軽減倍率0.8倍
	else:
		return 1.0 # その他等倍

func _on_e_command_command(act_id,index):
	enemy_id = Global.enemy_deck[index]["id"]
	enemy_form = Global.enemy_deck[index]["form"]
	if act_id == "10002": # 進化のmp設定
		mp_cost = int(monsters_data[enemy_id]["evolution"]["cost"])
	elif act_id == "10001": # 中間進化のmp設定
		mp_cost = int(monsters_data[enemy_id]["evolution_middle"]["cost"])
	else:
		mp_cost = int(Global.actions_data[act_id]["mp"])	
	if (
			index == 0 and int($enemy1/enemy1/e1_mp.value) < mp_cost or 
			index == 1 and int($enemy2/enemy2/e2_mp.value) < mp_cost or 
			index == 2 and int($enemy3/enemy3/e3_mp.value) < mp_cost):
		$"../log_window/log".text += "[color=yellow]相手はMPが足りない！[/color]\n"
	else: # mpが不足していないかチェック
		if index == 0:
			$enemy1/enemy1/e1_mp.value -= float(mp_cost)
		elif index == 1:
			$enemy2/enemy2/e2_mp.value -= float(mp_cost)
		elif index == 2:
			$enemy3/enemy3/e3_mp.value -= float(mp_cost)
		if mp_cost != 0:
			$"../log_window/log".text += (
				"相手の" + monsters_data[enemy_id][enemy_form]["name"] + 
				"は[color=aqua]" + str(mp_cost) + "MP[/color]を消費した...\n")
		$"../log_window/log".text += (
				"相手の" + monsters_data[enemy_id][enemy_form]["name"] + 
				"の" + actions_data[act_id]["name"] + "!\n")
		mp.emit()
		if act_id == "10002":
			$"../log_window/log".text += (
					"[color=red]相手の" + monsters_data[enemy_id][enemy_form]["name"] + " は " + 
					monsters_data[enemy_id]["evolution"]["name"] + " に進化した！[/color]\n")
			Global.enemy_deck[index]["form"] = "evolution"
			if index == 0:
				evolution1.emit()
			elif index == 1:
				evolution2.emit()
			elif index == 2:
				evolution3.emit()
		elif act_id == "10001":
			$"../log_window/log".text += (
					"[color=red]相手の" + monsters_data[enemy_id][enemy_form]["name"] + " は " + 
					monsters_data[enemy_id]["evolution_middle"]["name"] + " に進化した！[/color]\n")
			Global.enemy_deck[index]["form"] = "evolution_middle"
			if index == 0:
				evolution_middle1.emit()
			elif index == 1:
				evolution_middle2.emit()
			elif index == 2:
				evolution_middle3.emit()
		target = randi() % 3 # 常にランダムターゲット
		if actions_data[act_id]["damage_type"] == "0": # 参照するステータスのない技
			# 処理が簡単なのではじめに記述し、その他をelseに流す
			pass
		else:
			if actions_data[act_id]["damage_type"] == "1": # 物理技 ATK DEFを挿入
				dmg_type.clear()
				dmg_type.append("ATK")
				dmg_type.append("DEF")
			elif actions_data[act_id]["damage_type"] == "2": # 魔法技 MAG RESを挿入
				dmg_type.clear()
				dmg_type.append("MAG")
				dmg_type.append("RES")
			if actions_data[act_id]["ability_type"] == "9": # 属性付加持ちの技の場合
				o_sub = int(actions_data[act_id]["ability"]) # 複合属性判定を追加する
			else:
				o_sub = -1 # そうでない場合、該当なしを示す-1を挿入
			if actions_data[act_id]["range"] == "0": # 敵単体を攻撃する技だった時
				# ma2には属性相性の計算を行った結果の倍率(float)が入る
				monster_id = Global.deck1[target]["id"]
				monster_form = Global.deck1[target]["form"]
				ma2 *= attribute_setup( # 属性相性計算
						int(actions_data[act_id]["type_id"]),o_sub,
						Global.type_changer_id[monsters_data[monster_id][monster_form]["main_type"]],
						Global.type_changer_id[monsters_data[monster_id][monster_form]["sub_type"]])
				if ma2 >= 2.0:
					$"../log_window/log".text += "[color=red]弱点をついた！[/color]\n"
				elif ma2 < 1.0:
					$"../log_window/log".text += "[color=light_blue]耐性があるようだ...[/color]\n"
				if ( # モンスターと技の属性一致倍率処理
							int(actions_data[act_id]["type_id"]) == 
							Global.type_changer_id[monsters_data[enemy_id][enemy_form]["main_type"]] or 
							int(actions_data[act_id]["type_id"]) == 
							Global.type_changer_id[monsters_data[enemy_id][enemy_form]["sub_type"]]):
					ma2 *= 1.5
				print("type:","攻撃側1タイプ目:",int(actions_data[act_id]["type_id"]),"攻撃側2タイプ目:",o_sub,
						"防御側1タイプ目:",Global.type_changer_id[monsters_data[monster_id][monster_form]["main_type"]],
						"防御側2タイプ目:",Global.type_changer_id[monsters_data[monster_id][monster_form]["sub_type"]])
				print("属性倍率：",ma2)
# 以下ではダメージ計算処理を行っている 算出されたダメージを引数として直接関数を呼び出し相手のHPを減らす
# 技の基礎威力 * 攻撃側のATK(MAG) / 防御側のDEF(RES) * ma2(関数で呼び出した属性相性倍率)
				damage = (
						int(actions_data[act_id]["power"]) * 
						int(monsters_data[enemy_id][enemy_form]["status"]["ATK"]) / 
						int(monsters_data[monster_id][monster_form]["status"]["DEF"]) * ma2)
				if target == 0:
					damage1.emit(int(damage))
				elif target == 1:
					damage2.emit(int(damage))
				elif target == 2:
					damage3.emit(int(damage))
		ma2 = 1.0

func _on_e_2_command_command(act_id,index):
	call("_on_e_command_command",act_id,index)

func _on_e_3_command_command(act_id,index):
	call("_on_e_command_command",act_id,index)
