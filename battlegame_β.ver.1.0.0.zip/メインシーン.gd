extends Node2D

func _on_button_pressed():
	# 定義したシーンに切り替え
	get_tree().change_scene_to_packed(Global.deck_scene)
	
