extends Control

var monsters_data = Global.monsters_data

func _on_戻る_button_up():
	get_tree().change_scene_to_packed(Global.deck_scene)

func status(i):
	$ステータス.text = (
			"[b][i]「" + monsters_data[i]["default"]["name"] + "」[/i][/b]\n[img=50]" + 
			monsters_data[i]["default"]["main_type"] + "[/img][img]" + monsters_data[i]["default"]["sub_type"] + 
			"[/img] " + Global.type_changer_text[monsters_data[i]["default"]["main_type"]] + 
			" " + Global.type_changer_text[monsters_data[i]["default"]["sub_type"]] + "\n[color=red]HP:" +
			str(monsters_data[i]["default"]["status"]["HP"]) + "[/color] [color=green]SPD:" + 
			str(monsters_data[i]["default"]["status"]["SPD"]) + "[/color]\n[color=aqua]MP(supply/max):\n" + 
			str(monsters_data[i]["default"]["status"]["supplyMP"]) + "/" + 
			str(monsters_data[i]["default"]["status"]["maxMP"]) + "[/color]\n[color=red]ATK:" + 
			str(monsters_data[i]["default"]["status"]["ATK"]) + "[/color] [color=light_blue]DEF:" + 
			str(monsters_data[i]["default"]["status"]["DEF"]) + "[/color]\n[color=blue]MAG:" + 
			str(monsters_data[i]["default"]["status"]["MAG"]) + "[/color] [color=purple]RES:" + 
			str(monsters_data[i]["default"]["status"]["RES"]) + "[/color]")

func _on_スライム_mouse_entered():
	call("status",1)

func _on_スライム_button_up():
	Global.selected_monster = 1
	get_tree().change_scene_to_packed(Global.select_scene)

func _on_ゴースト_mouse_entered():
	call("status",2)

func _on_ゴースト_button_up():
	Global.selected_monster = 2
	get_tree().change_scene_to_packed(Global.select_scene)

func _on_バニン_mouse_entered():
	call("status",3)

func _on_バニン_button_up():
	Global.selected_monster = 3
	get_tree().change_scene_to_packed(Global.select_scene)

func _on_ラシュ_mouse_entered():
	pass # Replace with function body.
