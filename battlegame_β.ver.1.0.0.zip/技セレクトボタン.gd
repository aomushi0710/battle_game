extends Button

const act_button = preload("res://技セレクトボタン.tscn")
