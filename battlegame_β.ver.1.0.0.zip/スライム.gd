extends Sprite2D

signal command

@onready var bar = get_node("ProgressBar")
@onready var bar2 = get_node("TextureProgressBar")

func _process(delta: float) -> void:
	
	# プログレスバー増加アニメーション
	bar.value += 30 * delta

