extends TextureProgressBar

var supplyMP = 0
var maxMP = 0
var mp = 0
var mp_text = ""
var maxMP_text = ""

signal update_bar

func _on_tree_entered():# enemiesの相手デッキ生成スクリプトが作動してからステータスを取得しなければならない
	supplyMP = int(Global.monsters_data[Global.enemy_deck[2]["id"]]["default"]["status"]["supplyMP"])
	maxMP = int(Global.monsters_data[Global.enemy_deck[2]["id"]]["default"]["status"]["maxMP"])
	$".".max_value = maxMP
	$".".value = maxMP / 5
	if maxMP < 10: # 行揃え
		maxMP_text = "  " + str(maxMP)
	elif maxMP < 100:
		maxMP_text = " " + str(maxMP)
	else:
		maxMP_text = str(maxMP)
	call("text_update")

func _on_e_3_spd_mp():
	$".".value += supplyMP
	call("text_update")
	
func text_update():
	mp = int($".".value)
	if mp < 10: # 行揃え
		mp_text = "  " + str(mp)
	elif mp < 100:
		mp_text = " " + str(mp)
	else:
		mp_text = str(mp)
	$mp_text.text = "[color=aqua][b]MP[/b] " + mp_text + "/" + maxMP_text + "[/color]"

func _on_enemies_evolution_3():
	maxMP_text = str(Global.monsters_data[Global.enemy_deck[2]["id"]]["evolution"]["status"]["maxMP"])
	$".".max_value = int(Global.monsters_data[Global.enemy_deck[2]["id"]]["evolution"]["status"]["maxMP"])
	supplyMP = int(Global.monsters_data[Global.enemy_deck[2]["id"]]["evolution"]["status"]["supplyMP"])
	call("text_update")

func _on_enemies_evolution_middle_3():
	maxMP_text = Global.monsters_data[Global.enemy_deck[2]["id"]]["evolution_middle"]["status"]["maxMP"]
	$".".max_value = int(Global.monsters_data[Global.enemy_deck[2]["id"]]["evolution_middle"]["status"]["maxMP"])
	supplyMP = int(Global.monsters_data[Global.enemy_deck[2]["id"]]["evolution_middle"]["status"]["supplyMP"])
	call("text_update")
