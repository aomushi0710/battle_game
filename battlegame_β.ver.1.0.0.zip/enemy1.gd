extends TextureButton

var monsters_data = Global.monsters_data
var status = {
		"HP":int(monsters_data[Global.enemy_deck[0]["id"]]["default"]["status"]["HP"]),
		"maxMP":int(monsters_data[Global.enemy_deck[0]["id"]]["default"]["status"]["maxMP"]),
		"supplyMP":int(monsters_data[Global.enemy_deck[0]["id"]]["default"]["status"]["supplyMP"]),
		"ATK":int(monsters_data[Global.enemy_deck[0]["id"]]["default"]["status"]["ATK"]),
		"DEF":int(monsters_data[Global.enemy_deck[0]["id"]]["default"]["status"]["DEF"]),
		"MAG":int(monsters_data[Global.enemy_deck[0]["id"]]["default"]["status"]["MAG"]),
		"RES":int(monsters_data[Global.enemy_deck[0]["id"]]["default"]["status"]["RES"]),
		"SPD":int(monsters_data[Global.enemy_deck[0]["id"]]["default"]["status"]["SPD"])} 
var now_hp = 0
var now_mp = 0
var value = 0
var evolution_id = ""

signal randomize_set

func _on_tree_entered():
	$".".texture_normal = load(monsters_data[Global.enemy_deck[0]["id"]]["default"]["img"])
	$name.text = (
			"[img=50]" + monsters_data[Global.enemy_deck[0]["id"]]["default"]["main_type"] + 
			"[/img][img=50]" + monsters_data[Global.enemy_deck[0]["id"]]["default"]["sub_type"] + 
			"[/img] [b][i]" + monsters_data[Global.enemy_deck[0]["id"]]["default"]["name"] + "[/i][/b]
			")
	now_hp = status["HP"] 
	now_mp = status["maxMP"] / 5
	if "evolution" in Global.enemy_deck[0].keys():
		# なぜか、evolution_id = [Global.deck1[0]["evolution"]]のevolution_idがarray型になるバグ
		# があるため、for文で無理やりarray型らしきものからstr型へ修正している
		for i in [Global.enemy_deck[0]["evolution"]]: # 本来はarrayではないのだが、forで取り出さざるをえない
			evolution_id = i
		value = Global.enemy_deck[0]["actions"][Global.enemy_deck[0]["evolution"]] # 進化技の確率を取り出し
		Global.enemy_deck[0]["actions"].erase(str(evolution_id)) # 進化技のidを削除
		Global.enemy_deck[0]["actions"]["10002"] = value # 進化技挿入
	if "evolution_middle" in Global.enemy_deck[0].keys(): # 中間進化技の対応
		for i in [Global.enemy_deck[0]["evolution_middle"]]:
			evolution_id = i
		value = Global.enemy_deck[0]["actions"][Global.enemy_deck[0]["evolution_middle"]]
		Global.enemy_deck[0]["actions"].erase(str(evolution_id))
		Global.enemy_deck[0]["actions"]["10001"] = value
	Global.selected_action_name = Global.enemy_deck[0]["actions"].keys() # 進化を反映したものに上書き
	randomize_set.emit()

func _on_enemies_evolution_1():
	$".".texture_normal = load(monsters_data[Global.enemy_deck[0]["id"]]["evolution"]["img"])
	$name.text = (
		"[img=50]" + monsters_data[Global.enemy_deck[0]["id"]]["evolution"]["main_type"] + 
		"[/img][img=50]" + monsters_data[Global.enemy_deck[0]["id"]]["evolution"]["sub_type"] + 
		"[/img] [b][i]" + monsters_data[Global.enemy_deck[0]["id"]]["evolution"]["name"] + "[/i][/b]")
	value = Global.enemy_deck[0]["actions"]["10002"] # 進化技の確率を取り出し
	Global.enemy_deck[0]["actions"].erase("10002") # 進化技のidを削除
	Global.enemy_deck[0]["actions"][Global.enemy_deck[0]["evolution"]] = value # 進化技挿入

func _on_enemies_evolution_middle_1():
	$".".texture_normal = load(monsters_data[Global.enemy_deck[0]["id"]]["evolution_middle"]["img"])
	$name.text = (
		"[img=50]" + monsters_data[Global.enemy_deck[0]["id"]]["evolution_middle"]["main_type"] + 
		"[/img][img=50]" + monsters_data[Global.enemy_deck[0]["id"]]["evolution_middle"]["sub_type"] + 
		"[/img] [b][i]" + monsters_data[Global.enemy_deck[0]["id"]]["evolution_middle"]["name"] + "[/i][/b]")
	value = Global.enemy_deck[0]["actions"]["10001"] # 進化技の確率を取り出し
	Global.enemy_deck[0]["actions"].erase("10001") # 進化技のidを削除
	Global.enemy_deck[0]["actions"][Global.enemy_deck[0]["evolution_middle"]] = value # 進化技挿入
