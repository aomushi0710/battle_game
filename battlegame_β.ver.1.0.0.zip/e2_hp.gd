extends TextureProgressBar

var maxHP = 0
var hp = 0
var hp_text = ""

func _on_tree_entered(): # enemiesの相手デッキ生成スクリプトが作動してからステータスを取得しなければならない
	maxHP = int(Global.monsters_data[Global.enemy_deck[1]["id"]]["default"]["status"]["HP"])
	$".".max_value = maxHP
	$".".value = maxHP
	call("text_update")

func text_update():
	hp = int($".".value)
	if hp < 10:
		hp_text = "  " + str(hp)
	elif hp < 100:
		hp_text = " " + str(hp)
	else:
		hp_text = str(hp)
	$hp_text.text = "[color=red][b]HP[/b] " + hp_text + "/" + str(maxHP) + "[/color]"


func _on_buttle_damage_1(dmg):
	$".".value -= dmg
	$"/root/Node2D/log_window/log".text += (
			"相手の" + Global.monsters_data[Global.enemy_deck[1]["id"]][Global.enemy_deck[1]["form"]]["name"] + 
			"に[color=red]" + str(dmg) + "[/color]ダメージを与えた！\n")
	call("text_update")

func _on_enemies_evolution_2(): # 進化時、増えたmaxHPの分だけ今のHPに追加して回復する
	$".".max_value = int(Global.monsters_data[Global.enemy_deck[1]["id"]]["evolution"]["status"]["HP"])
	$".".value += int(Global.monsters_data[Global.enemy_deck[1]["id"]]["evolution"]["status"]["HP"]) - maxHP
	maxHP = int(Global.monsters_data[Global.enemy_deck[1]["id"]]["evolution"]["status"]["HP"])
	call("text_update")

func _on_enemies_evolution_middle_2():
	$".".max_value = int(Global.monsters_data[Global.enemy_deck[1]["id"]]["evolution_middle"]["status"]["HP"])
	$".".value += int(Global.monsters_data[Global.enemy_deck[1]["id"]]["evolution_middle"]["status"]["HP"]) - maxHP
	maxHP = int(Global.monsters_data[Global.enemy_deck[1]["id"]]["evolution_middle"]["status"]["HP"])
	call("text_update")
