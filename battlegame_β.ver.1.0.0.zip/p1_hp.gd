extends TextureProgressBar

var maxHP = int(Global.monsters_data[Global.deck1[0]["id"]]["default"]["status"]["HP"])
var hp = 0
var hp_text = ""

func _on_tree_entered():
	$".".max_value = maxHP
	$".".value = maxHP
	call("text_update")

func text_update():
	hp = int($".".value)
	if hp < 10:
		hp_text = "  " + str(hp)
	elif hp < 100:
		hp_text = " " + str(hp)
	else:
		hp_text = str(hp)
	$hp_text.text = "[color=red][b]HP[/b] " + hp_text + "/" + str(maxHP) + "[/color]"

func _on_enemies_damage_1(dmg):
	$".".value -= dmg
	$"/root/Node2D/log_window/log".text += (
			Global.monsters_data[Global.deck1[0]["id"]][Global.deck1[0]["form"]]["name"] + 
			"は[color=red]" + str(dmg) + "[/color]ダメージを受けた！\n")
	call("text_update")

func _on_buttle_evolution_1(): # 進化時、増えたmaxHPの分だけ今のHPに追加して回復する
	$".".max_value = int(Global.monsters_data[Global.deck1[0]["id"]]["evolution"]["status"]["HP"])
	$".".value += int(Global.monsters_data[Global.deck1[0]["id"]]["evolution"]["status"]["HP"]) - maxHP
	maxHP = int(Global.monsters_data[Global.deck1[0]["id"]]["evolution"]["status"]["HP"])
	call("text_update")

func _on_buttle_evolution_middle_1():
	$".".max_value = int(Global.monsters_data[Global.deck1[0]["id"]]["evolution_middle"]["status"]["HP"])
	$".".value += int(Global.monsters_data[Global.deck1[0]["id"]]["evolution_middle"]["status"]["HP"]) - maxHP
	maxHP = int(Global.monsters_data[Global.deck1[0]["id"]]["evolution_middle"]["status"]["HP"])
	call("text_update")
